package com.example.collageapp.Notification;

public class Token {
    public String Token;

    public Token(String token) {
        Token = token;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        this.Token = token;
    }
}
